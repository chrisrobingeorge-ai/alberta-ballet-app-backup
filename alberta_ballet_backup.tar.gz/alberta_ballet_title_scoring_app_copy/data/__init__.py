# Data module initialization
